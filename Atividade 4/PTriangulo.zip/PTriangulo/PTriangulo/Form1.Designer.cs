﻿namespace PTriangulo
{
    partial class PTriangulos
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnex = new System.Windows.Forms.Button();
            this.btnlimp = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.Lbll1 = new System.Windows.Forms.Label();
            this.Lbll2 = new System.Windows.Forms.Label();
            this.Lbll3 = new System.Windows.Forms.Label();
            this.txtl1 = new System.Windows.Forms.TextBox();
            this.txtl2 = new System.Windows.Forms.TextBox();
            this.txtl3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::PTriangulo.Properties.Resources.tongo_dancing;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(241, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(297, 292);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnex
            // 
            this.btnex.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnex.Location = new System.Drawing.Point(60, 163);
            this.btnex.Name = "btnex";
            this.btnex.Size = new System.Drawing.Size(100, 47);
            this.btnex.TabIndex = 1;
            this.btnex.Text = "Executar";
            this.btnex.UseVisualStyleBackColor = true;
            this.btnex.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnlimp
            // 
            this.btnlimp.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnlimp.Location = new System.Drawing.Point(60, 227);
            this.btnlimp.Name = "btnlimp";
            this.btnlimp.Size = new System.Drawing.Size(100, 47);
            this.btnlimp.TabIndex = 2;
            this.btnlimp.Text = "Limpar";
            this.btnlimp.UseVisualStyleBackColor = true;
            this.btnlimp.Click += new System.EventHandler(this.btnlimp_Click);
            // 
            // btnsair
            // 
            this.btnsair.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnsair.Location = new System.Drawing.Point(60, 293);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(100, 47);
            this.btnsair.TabIndex = 3;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // Lbll1
            // 
            this.Lbll1.AutoSize = true;
            this.Lbll1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lbll1.Location = new System.Drawing.Point(29, 51);
            this.Lbll1.Name = "Lbll1";
            this.Lbll1.Size = new System.Drawing.Size(59, 18);
            this.Lbll1.TabIndex = 4;
            this.Lbll1.Text = "Lado 1:";
            // 
            // Lbll2
            // 
            this.Lbll2.AutoSize = true;
            this.Lbll2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lbll2.Location = new System.Drawing.Point(29, 84);
            this.Lbll2.Name = "Lbll2";
            this.Lbll2.Size = new System.Drawing.Size(59, 18);
            this.Lbll2.TabIndex = 5;
            this.Lbll2.Text = "Lado 2:";
            // 
            // Lbll3
            // 
            this.Lbll3.AutoSize = true;
            this.Lbll3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lbll3.Location = new System.Drawing.Point(29, 117);
            this.Lbll3.Name = "Lbll3";
            this.Lbll3.Size = new System.Drawing.Size(59, 18);
            this.Lbll3.TabIndex = 6;
            this.Lbll3.Text = "Lado 3:";
            // 
            // txtl1
            // 
            this.txtl1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtl1.Location = new System.Drawing.Point(88, 48);
            this.txtl1.Name = "txtl1";
            this.txtl1.Size = new System.Drawing.Size(137, 25);
            this.txtl1.TabIndex = 7;
            this.txtl1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtl1_KeyPress);
            // 
            // txtl2
            // 
            this.txtl2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtl2.Location = new System.Drawing.Point(88, 79);
            this.txtl2.Name = "txtl2";
            this.txtl2.Size = new System.Drawing.Size(137, 25);
            this.txtl2.TabIndex = 8;
            this.txtl2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtl1_KeyPress);
            // 
            // txtl3
            // 
            this.txtl3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtl3.Location = new System.Drawing.Point(88, 110);
            this.txtl3.Name = "txtl3";
            this.txtl3.Size = new System.Drawing.Size(137, 25);
            this.txtl3.TabIndex = 9;
            this.txtl3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtl1_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(146, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 35);
            this.label1.TabIndex = 10;
            this.label1.Text = "Aceitas triângulos?";
            // 
            // PTriangulos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 362);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtl3);
            this.Controls.Add(this.txtl2);
            this.Controls.Add(this.txtl1);
            this.Controls.Add(this.Lbll3);
            this.Controls.Add(this.Lbll2);
            this.Controls.Add(this.Lbll1);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimp);
            this.Controls.Add(this.btnex);
            this.Controls.Add(this.pictureBox1);
            this.Name = "PTriangulos";
            this.Text = "Aceitas triângulos ?";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private Button btnex;
        private Button btnlimp;
        private Button btnsair;
        private Label Lbll1;
        private Label Lbll2;
        private Label Lbll3;
        private TextBox txtl1;
        private TextBox txtl2;
        private TextBox txtl3;
        private Label label1;
    }
}