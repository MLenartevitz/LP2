namespace PTriangulo
{
    public partial class PTriangulos : Form
    {
        public PTriangulos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //btnex
        {
            double L1, L2, L3;

            if (!double.TryParse(txtl1.Text, out L1) ||
               !double.TryParse(txtl2.Text, out L2) ||
               !double.TryParse(txtl3.Text, out L3))
            {
                MessageBox.Show("Deve se posto valores numericos");
            }
            else
            {

                if (L1 < (L2 + L3) && L1 > Math.Abs(L2 - L3) && L2 < (L1 + L3) && L2 > Math.Abs(L1 - L2) && L3 < (L1 + L2) && L3 > Math.Abs(L1 - L2))
                 {
                    if (L1 == L2 && L2 == L3)
                    {
                        MessageBox.Show("O tri�ngulo � equil�tero!");
                    }

                    else if ((L1 == L2 && L2!=L3) || (L1 == L3 && L3!= L2) || (L2 == L3 && L3!= L1))
                        {
                            MessageBox.Show("O tri�ngulo � is�sceles !");
                        }
                        else
                        {
                            MessageBox.Show("O tri�ngulo � escaleno!");
                        }                   
                }
            }
        }

        private void btnlimp_Click(object sender, EventArgs e)
        {
            //Limpar os dados
            txtl1.Clear();
            txtl2.Text = "";
            txtl3.Text = string.Empty;

            txtl1.Focus();

        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Aten��o", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                Close();
            }
            else
            {
                txtl1.Focus();
            }

        }

        private void txtl1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{tab}");
                e.Handled = true;
            }

        }
    }
}