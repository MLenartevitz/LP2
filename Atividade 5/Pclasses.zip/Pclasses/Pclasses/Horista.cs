﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    class Horista : Empregado
    {
        //prop e 2 x tab cria a estrutura de propriedade
        public double SalarioHora { get; set; }

        public double NumeroHora { get; set; }

        public int DiasFalta { get; set; }


        public  override double SalarioBruto()
        {
            return (SalarioHora * NumeroHora);
        }

        //override indica subescrever

        public override int TempoTrabalho()
        {
            //Método retorno um tipo span
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days - DiasFalta);
        }
    }
}
