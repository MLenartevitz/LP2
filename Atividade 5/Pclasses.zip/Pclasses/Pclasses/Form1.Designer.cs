﻿namespace Pclasses
{
    partial class FRMprincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnMe = new System.Windows.Forms.Button();
            this.BtnHo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnMe
            // 
            this.BtnMe.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnMe.Location = new System.Drawing.Point(463, 74);
            this.BtnMe.Name = "BtnMe";
            this.BtnMe.Size = new System.Drawing.Size(193, 69);
            this.BtnMe.TabIndex = 0;
            this.BtnMe.Text = "Mensalista";
            this.BtnMe.UseVisualStyleBackColor = true;
            this.BtnMe.Click += new System.EventHandler(this.BtnMe_Click);
            // 
            // BtnHo
            // 
            this.BtnHo.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnHo.Location = new System.Drawing.Point(463, 160);
            this.BtnHo.Name = "BtnHo";
            this.BtnHo.Size = new System.Drawing.Size(193, 69);
            this.BtnHo.TabIndex = 1;
            this.BtnHo.Text = "Horista";
            this.BtnHo.UseVisualStyleBackColor = true;
            this.BtnHo.Click += new System.EventHandler(this.BtnHo_Click);
            // 
            // FRMprincipal
            // 
            this.AccessibleName = "frmPrincipal";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Pclasses.Properties.Resources.b6e50e81fe10b9f70b2bd939d33c84d5aaace64a_hq2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(691, 393);
            this.Controls.Add(this.BtnHo);
            this.Controls.Add(this.BtnMe);
            this.Name = "FRMprincipal";
            this.Text = "Principal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnMe;
        private System.Windows.Forms.Button BtnHo;

    }
}

