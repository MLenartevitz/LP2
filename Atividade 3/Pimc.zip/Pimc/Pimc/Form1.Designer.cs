﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPa = new System.Windows.Forms.Label();
            this.LblAt = new System.Windows.Forms.Label();
            this.TxtPa = new System.Windows.Forms.TextBox();
            this.TxtAt = new System.Windows.Forms.TextBox();
            this.BtnCal = new System.Windows.Forms.Button();
            this.BtnLimp = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.LblRe = new System.Windows.Forms.Label();
            this.TxtRe = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblPa
            // 
            this.LblPa.AutoSize = true;
            this.LblPa.BackColor = System.Drawing.Color.Transparent;
            this.LblPa.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblPa.Location = new System.Drawing.Point(12, 21);
            this.LblPa.Name = "LblPa";
            this.LblPa.Size = new System.Drawing.Size(86, 18);
            this.LblPa.TabIndex = 0;
            this.LblPa.Text = "Peso Atual:";
            // 
            // LblAt
            // 
            this.LblAt.AutoSize = true;
            this.LblAt.BackColor = System.Drawing.Color.Transparent;
            this.LblAt.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblAt.Location = new System.Drawing.Point(12, 49);
            this.LblAt.Name = "LblAt";
            this.LblAt.Size = new System.Drawing.Size(53, 18);
            this.LblAt.TabIndex = 1;
            this.LblAt.Text = "Altura:";
            this.LblAt.Click += new System.EventHandler(this.label2_Click);
            // 
            // TxtPa
            // 
            this.TxtPa.Location = new System.Drawing.Point(104, 21);
            this.TxtPa.Name = "TxtPa";
            this.TxtPa.Size = new System.Drawing.Size(100, 23);
            this.TxtPa.TabIndex = 2;
            // 
            // TxtAt
            // 
            this.TxtAt.Location = new System.Drawing.Point(104, 50);
            this.TxtAt.Name = "TxtAt";
            this.TxtAt.Size = new System.Drawing.Size(100, 23);
            this.TxtAt.TabIndex = 3;
            // 
            // BtnCal
            // 
            this.BtnCal.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCal.Location = new System.Drawing.Point(12, 199);
            this.BtnCal.Name = "BtnCal";
            this.BtnCal.Size = new System.Drawing.Size(96, 42);
            this.BtnCal.TabIndex = 4;
            this.BtnCal.Text = "Calcular";
            this.BtnCal.UseVisualStyleBackColor = true;
            this.BtnCal.Click += new System.EventHandler(this.BtnCal_Click);
            // 
            // BtnLimp
            // 
            this.BtnLimp.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnLimp.Location = new System.Drawing.Point(144, 200);
            this.BtnLimp.Name = "BtnLimp";
            this.BtnLimp.Size = new System.Drawing.Size(98, 41);
            this.BtnLimp.TabIndex = 5;
            this.BtnLimp.Text = "Limpar";
            this.BtnLimp.UseVisualStyleBackColor = true;
            this.BtnLimp.Click += new System.EventHandler(this.BtnLimp_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnSair.Location = new System.Drawing.Point(269, 199);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(96, 42);
            this.BtnSair.TabIndex = 6;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // LblRe
            // 
            this.LblRe.AutoSize = true;
            this.LblRe.BackColor = System.Drawing.Color.Transparent;
            this.LblRe.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblRe.Location = new System.Drawing.Point(12, 76);
            this.LblRe.Name = "LblRe";
            this.LblRe.Size = new System.Drawing.Size(84, 18);
            this.LblRe.TabIndex = 7;
            this.LblRe.Text = "Resultado:";
            // 
            // TxtRe
            // 
            this.TxtRe.Enabled = false;
            this.TxtRe.Location = new System.Drawing.Point(104, 76);
            this.TxtRe.Name = "TxtRe";
            this.TxtRe.Size = new System.Drawing.Size(100, 23);
            this.TxtRe.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(377, 281);
            this.Controls.Add(this.TxtRe);
            this.Controls.Add(this.LblRe);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimp);
            this.Controls.Add(this.BtnCal);
            this.Controls.Add(this.TxtAt);
            this.Controls.Add(this.TxtPa);
            this.Controls.Add(this.LblAt);
            this.Controls.Add(this.LblPa);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "IMC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label LblPa;
        private Label LblAt;
        private TextBox TxtPa;
        private TextBox TxtAt;
        private Button BtnCal;
        private Button BtnLimp;
        private Button BtnSair;
        private Label LblRe;
        private TextBox TxtRe;
    }
}