using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Aten��o", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                Close();
            }
            else
            {
                TxtPa.Focus();
            }

        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            //limpar os dados
            TxtPa.Clear();
            TxtAt.Text = "";
            TxtRe.Text = String.Empty;

            TxtPa.Focus();
        }

        private void BtnCal_Click(object sender, EventArgs e)
        {
            double Altura, Peso, Imc;
        if
            (double.TryParse(TxtPa.Text, out Peso) &&
                double.TryParse(TxtAt.Text, out Altura))
                
                {

                if ((Altura <= 0) || (Peso <= 0))
                {
                    MessageBox.Show("Valores devem ser maior que zero!", "Erro de valor!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    Imc = Peso / (Math.Pow(Altura, 2));

                    Imc = Math.Round(Imc, 1);
                    
                    TxtRe.Text = Imc.ToString("N1");

                    if (Imc < 18.5)
                        MessageBox.Show("Magreza");
                    else if (Imc < 24.9)
                        MessageBox.Show("Normal");
                    else if (Imc < 29.9)
                        MessageBox.Show("Sobrepeso");
                    else if (Imc > 39.9)
                        MessageBox.Show("Obesidade");
                    else 
                        MessageBox.Show("Obesidade m�rbida");

                }
           
        }
    }
    }
}