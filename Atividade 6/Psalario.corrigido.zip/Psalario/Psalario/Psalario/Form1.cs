﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e) //LBLNFUN
        {

        }

        private void BTNVALD_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if ( TXTNFUN.Text == String.Empty)
            {
                MessageBox.Show("O nome do funcionário" + "\n não pode ser vazio!");
            }

            else
            {
              if (!double.TryParse(MSKTXTSALB.Text, out salarioBruto)
                  || !double.TryParse(TXTNUMF.Text, out numeroFilhos))
              {
                  MessageBox.Show("Salário bruto e número de filhos  devem ser números");
              } 
              else
              {
                  if(salarioBruto <= 0)
                      MessageBox.Show("Salário bruto dever maior que zero 0!");
                  else
                  {
                      if(salarioBruto <= 800.47)
                      {
                          MSKTXTSALB.Text= "7,65";
                          descontoINSS = 0.0765 * salarioBruto;
                      }
                      else if (salarioBruto <= 1050)
                      {
                          TXTAINSS.Text = "8,65";
                          descontoINSS = ((8.65 / 100) * salarioBruto);
                      }
                      else if (salarioBruto <= 1400.77)
                      {
                          TXTAINSS.Text = "11,00";
                          descontoINSS = 0.11 * salarioBruto;      
                      }
                      else
                      {
                          TXTAINSS.Text = "11,00";
                          descontoINSS = 308.17; 
                      }

                      TXTDESINSS.Text = descontoINSS.ToString("N2");

                      //desconto do imposto de renda
                      if (salarioBruto <= 1257.12)
                         TXTDESIRPF.Text = "0";
                      else if (salarioBruto <= 2512.08)
                      {
                         TXTDESIRPF.Text = "15%";
                         descontoIRPF = (salarioBruto * 15 / 100);
                      }
                      else
                      {
                         TXTAIRPF.Text = "27,5%";
                         descontoIRPF = (salarioBruto * 27.5 / 100);
                      }

                      TXTDESIRPF.Text = descontoIRPF.ToString("N2");

                      //salario familia
                      if(numeroFilhos > 0)
                      {
                            if (salarioBruto <= 435.52)
                                salarioFamilia = (22.53 * numeroFilhos);
                            else if (salarioFamilia <= 654.61)
                                salarioFamilia = (15.74 * numeroFilhos);
                            else
                                salarioFamilia = 0;
                      }

                      TXTSALF.Text = salarioFamilia.ToString("N2");

                      salarioLiquido = salarioBruto - descontoINSS - descontoIRPF - salarioFamilia;

                      TXTSALL.Text = salarioLiquido.ToString("N2");

                      //parte do lbldados
                      LBLDADOS.Text = "Os descontos do salário " +
                           (RBXF.Checked ? "da Sra. " : "do Sr. ") +
                           TXTNFUN.Text + " que é " +
                           (RBNCAS.Checked ? "Casado(a)" : "Solteiro(a)") +
                           " e que tem " +
                           Convert.ToString(numeroFilhos) + " Filho(s) são:";

                    }

                }
            }
        }
    }
}
