﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBLNFUN = new System.Windows.Forms.Label();
            this.LBLSALB = new System.Windows.Forms.Label();
            this.LBLNUMF = new System.Windows.Forms.Label();
            this.BTNVALD = new System.Windows.Forms.Button();
            this.LBLNAINSS = new System.Windows.Forms.Label();
            this.LBLAIRFF = new System.Windows.Forms.Label();
            this.LBLSALFAM = new System.Windows.Forms.Label();
            this.LBLSALLIQ = new System.Windows.Forms.Label();
            this.LBLDESINSS = new System.Windows.Forms.Label();
            this.LBLDESIRFF = new System.Windows.Forms.Label();
            this.TXTAIRPF = new System.Windows.Forms.TextBox();
            this.TXTSALF = new System.Windows.Forms.TextBox();
            this.TXTSALL = new System.Windows.Forms.TextBox();
            this.TXTDESIRPF = new System.Windows.Forms.TextBox();
            this.TXTNUMF = new System.Windows.Forms.ComboBox();
            this.LBLDADOS = new System.Windows.Forms.Label();
            this.RBNCAS = new System.Windows.Forms.RadioButton();
            this.GPXSEXO = new System.Windows.Forms.GroupBox();
            this.RBXM = new System.Windows.Forms.RadioButton();
            this.RBXF = new System.Windows.Forms.RadioButton();
            this.MSKTXTSALB = new System.Windows.Forms.MaskedTextBox();
            this.TXTNFUN = new System.Windows.Forms.TextBox();
            this.TXTAINSS = new System.Windows.Forms.TextBox();
            this.TXTDESINSS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.GPXSEXO.SuspendLayout();
            this.SuspendLayout();
            // 
            // LBLNFUN
            // 
            this.LBLNFUN.AutoSize = true;
            this.LBLNFUN.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLNFUN.Location = new System.Drawing.Point(6, 49);
            this.LBLNFUN.Name = "LBLNFUN";
            this.LBLNFUN.Size = new System.Drawing.Size(126, 18);
            this.LBLNFUN.TabIndex = 0;
            this.LBLNFUN.Text = "Nome funcionário";
            this.LBLNFUN.Click += new System.EventHandler(this.label1_Click);
            // 
            // LBLSALB
            // 
            this.LBLSALB.AutoSize = true;
            this.LBLSALB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLSALB.Location = new System.Drawing.Point(38, 85);
            this.LBLSALB.Name = "LBLSALB";
            this.LBLSALB.Size = new System.Drawing.Size(94, 18);
            this.LBLSALB.TabIndex = 1;
            this.LBLSALB.Text = "Salário Bruto";
            // 
            // LBLNUMF
            // 
            this.LBLNUMF.AutoSize = true;
            this.LBLNUMF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLNUMF.Location = new System.Drawing.Point(11, 124);
            this.LBLNUMF.Name = "LBLNUMF";
            this.LBLNUMF.Size = new System.Drawing.Size(121, 18);
            this.LBLNUMF.TabIndex = 2;
            this.LBLNUMF.Text = "Número de filhos";
            // 
            // BTNVALD
            // 
            this.BTNVALD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNVALD.Location = new System.Drawing.Point(138, 178);
            this.BTNVALD.Name = "BTNVALD";
            this.BTNVALD.Size = new System.Drawing.Size(209, 36);
            this.BTNVALD.TabIndex = 3;
            this.BTNVALD.Text = "Verificar Dados";
            this.BTNVALD.UseVisualStyleBackColor = true;
            this.BTNVALD.Click += new System.EventHandler(this.BTNVALD_Click);
            // 
            // LBLNAINSS
            // 
            this.LBLNAINSS.AutoSize = true;
            this.LBLNAINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLNAINSS.Location = new System.Drawing.Point(8, 294);
            this.LBLNAINSS.Name = "LBLNAINSS";
            this.LBLNAINSS.Size = new System.Drawing.Size(98, 18);
            this.LBLNAINSS.TabIndex = 7;
            this.LBLNAINSS.Text = "Aliquota INSS";
            // 
            // LBLAIRFF
            // 
            this.LBLAIRFF.AutoSize = true;
            this.LBLAIRFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLAIRFF.Location = new System.Drawing.Point(9, 356);
            this.LBLAIRFF.Name = "LBLAIRFF";
            this.LBLAIRFF.Size = new System.Drawing.Size(97, 18);
            this.LBLAIRFF.TabIndex = 8;
            this.LBLAIRFF.Text = "Aliquota IRPF";
            // 
            // LBLSALFAM
            // 
            this.LBLSALFAM.AutoSize = true;
            this.LBLSALFAM.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLSALFAM.Location = new System.Drawing.Point(1, 409);
            this.LBLSALFAM.Name = "LBLSALFAM";
            this.LBLSALFAM.Size = new System.Drawing.Size(105, 18);
            this.LBLSALFAM.TabIndex = 9;
            this.LBLSALFAM.Text = "Salário Familia";
            // 
            // LBLSALLIQ
            // 
            this.LBLSALLIQ.AutoSize = true;
            this.LBLSALLIQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLSALLIQ.Location = new System.Drawing.Point(1, 471);
            this.LBLSALLIQ.Name = "LBLSALLIQ";
            this.LBLSALLIQ.Size = new System.Drawing.Size(105, 18);
            this.LBLSALLIQ.TabIndex = 10;
            this.LBLSALLIQ.Text = "Salário Liquido";
            // 
            // LBLDESINSS
            // 
            this.LBLDESINSS.AutoSize = true;
            this.LBLDESINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLDESINSS.Location = new System.Drawing.Point(254, 294);
            this.LBLDESINSS.Name = "LBLDESINSS";
            this.LBLDESINSS.Size = new System.Drawing.Size(111, 18);
            this.LBLDESINSS.TabIndex = 11;
            this.LBLDESINSS.Text = "Desconto INSS";
            // 
            // LBLDESIRFF
            // 
            this.LBLDESIRFF.AutoSize = true;
            this.LBLDESIRFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLDESIRFF.Location = new System.Drawing.Point(254, 356);
            this.LBLDESIRFF.Name = "LBLDESIRFF";
            this.LBLDESIRFF.Size = new System.Drawing.Size(110, 18);
            this.LBLDESIRFF.TabIndex = 12;
            this.LBLDESIRFF.Text = "Desconto IRPF";
            // 
            // TXTAIRPF
            // 
            this.TXTAIRPF.Enabled = false;
            this.TXTAIRPF.Location = new System.Drawing.Point(112, 354);
            this.TXTAIRPF.Name = "TXTAIRPF";
            this.TXTAIRPF.Size = new System.Drawing.Size(108, 20);
            this.TXTAIRPF.TabIndex = 14;
            // 
            // TXTSALF
            // 
            this.TXTSALF.Enabled = false;
            this.TXTSALF.Location = new System.Drawing.Point(112, 409);
            this.TXTSALF.Name = "TXTSALF";
            this.TXTSALF.Size = new System.Drawing.Size(108, 20);
            this.TXTSALF.TabIndex = 15;
            // 
            // TXTSALL
            // 
            this.TXTSALL.Enabled = false;
            this.TXTSALL.Location = new System.Drawing.Point(112, 469);
            this.TXTSALL.Name = "TXTSALL";
            this.TXTSALL.Size = new System.Drawing.Size(108, 20);
            this.TXTSALL.TabIndex = 16;
            // 
            // TXTDESIRPF
            // 
            this.TXTDESIRPF.Enabled = false;
            this.TXTDESIRPF.Location = new System.Drawing.Point(371, 354);
            this.TXTDESIRPF.Name = "TXTDESIRPF";
            this.TXTDESIRPF.Size = new System.Drawing.Size(108, 20);
            this.TXTDESIRPF.TabIndex = 18;
            // 
            // TXTNUMF
            // 
            this.TXTNUMF.FormattingEnabled = true;
            this.TXTNUMF.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.TXTNUMF.Location = new System.Drawing.Point(138, 121);
            this.TXTNUMF.Name = "TXTNUMF";
            this.TXTNUMF.Size = new System.Drawing.Size(121, 21);
            this.TXTNUMF.TabIndex = 21;
            // 
            // LBLDADOS
            // 
            this.LBLDADOS.AutoSize = true;
            this.LBLDADOS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLDADOS.Location = new System.Drawing.Point(27, 249);
            this.LBLDADOS.Name = "LBLDADOS";
            this.LBLDADOS.Size = new System.Drawing.Size(66, 18);
            this.LBLDADOS.TabIndex = 22;
            this.LBLDADOS.Text = "lblDados";
            // 
            // RBNCAS
            // 
            this.RBNCAS.AutoSize = true;
            this.RBNCAS.Location = new System.Drawing.Point(402, 197);
            this.RBNCAS.Name = "RBNCAS";
            this.RBNCAS.Size = new System.Drawing.Size(61, 17);
            this.RBNCAS.TabIndex = 23;
            this.RBNCAS.Text = "Casado";
            this.RBNCAS.UseVisualStyleBackColor = true;
            // 
            // GPXSEXO
            // 
            this.GPXSEXO.Controls.Add(this.RBXM);
            this.GPXSEXO.Controls.Add(this.RBXF);
            this.GPXSEXO.Location = new System.Drawing.Point(383, 42);
            this.GPXSEXO.Name = "GPXSEXO";
            this.GPXSEXO.Size = new System.Drawing.Size(137, 100);
            this.GPXSEXO.TabIndex = 24;
            this.GPXSEXO.TabStop = false;
            this.GPXSEXO.Text = "Sexo";
            // 
            // RBXM
            // 
            this.RBXM.AutoSize = true;
            this.RBXM.Checked = true;
            this.RBXM.Location = new System.Drawing.Point(19, 66);
            this.RBXM.Name = "RBXM";
            this.RBXM.Size = new System.Drawing.Size(34, 17);
            this.RBXM.TabIndex = 25;
            this.RBXM.TabStop = true;
            this.RBXM.Text = "M";
            this.RBXM.UseVisualStyleBackColor = true;
            // 
            // RBXF
            // 
            this.RBXF.AutoSize = true;
            this.RBXF.Location = new System.Drawing.Point(19, 28);
            this.RBXF.Name = "RBXF";
            this.RBXF.Size = new System.Drawing.Size(31, 17);
            this.RBXF.TabIndex = 24;
            this.RBXF.Text = "F";
            this.RBXF.UseVisualStyleBackColor = true;
            // 
            // MSKTXTSALB
            // 
            this.MSKTXTSALB.Location = new System.Drawing.Point(138, 86);
            this.MSKTXTSALB.Mask = "999999999,00";
            this.MSKTXTSALB.Name = "MSKTXTSALB";
            this.MSKTXTSALB.Size = new System.Drawing.Size(121, 20);
            this.MSKTXTSALB.TabIndex = 25;
            // 
            // TXTNFUN
            // 
            this.TXTNFUN.Location = new System.Drawing.Point(138, 50);
            this.TXTNFUN.Name = "TXTNFUN";
            this.TXTNFUN.Size = new System.Drawing.Size(121, 20);
            this.TXTNFUN.TabIndex = 26;
            // 
            // TXTAINSS
            // 
            this.TXTAINSS.Enabled = false;
            this.TXTAINSS.Location = new System.Drawing.Point(112, 292);
            this.TXTAINSS.Name = "TXTAINSS";
            this.TXTAINSS.Size = new System.Drawing.Size(108, 20);
            this.TXTAINSS.TabIndex = 13;
            // 
            // TXTDESINSS
            // 
            this.TXTDESINSS.Enabled = false;
            this.TXTDESINSS.Location = new System.Drawing.Point(371, 295);
            this.TXTDESINSS.Name = "TXTDESINSS";
            this.TXTDESINSS.Size = new System.Drawing.Size(108, 20);
            this.TXTDESINSS.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(252, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 29);
            this.label1.TabIndex = 28;
            this.label1.Text = "Trabalho salário 💸 ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(724, 517);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TXTDESINSS);
            this.Controls.Add(this.TXTNFUN);
            this.Controls.Add(this.MSKTXTSALB);
            this.Controls.Add(this.GPXSEXO);
            this.Controls.Add(this.RBNCAS);
            this.Controls.Add(this.LBLDADOS);
            this.Controls.Add(this.TXTNUMF);
            this.Controls.Add(this.TXTDESIRPF);
            this.Controls.Add(this.TXTSALL);
            this.Controls.Add(this.TXTSALF);
            this.Controls.Add(this.TXTAIRPF);
            this.Controls.Add(this.TXTAINSS);
            this.Controls.Add(this.LBLDESIRFF);
            this.Controls.Add(this.LBLDESINSS);
            this.Controls.Add(this.LBLSALLIQ);
            this.Controls.Add(this.LBLSALFAM);
            this.Controls.Add(this.LBLAIRFF);
            this.Controls.Add(this.LBLNAINSS);
            this.Controls.Add(this.BTNVALD);
            this.Controls.Add(this.LBLNUMF);
            this.Controls.Add(this.LBLSALB);
            this.Controls.Add(this.LBLNFUN);
            this.Name = "Form1";
            this.Text = "Form1";
            this.GPXSEXO.ResumeLayout(false);
            this.GPXSEXO.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBLNFUN;
        private System.Windows.Forms.Label LBLSALB;
        private System.Windows.Forms.Label LBLNUMF;
        private System.Windows.Forms.Button BTNVALD;
        private System.Windows.Forms.Label LBLNAINSS;
        private System.Windows.Forms.Label LBLAIRFF;
        private System.Windows.Forms.Label LBLSALFAM;
        private System.Windows.Forms.Label LBLSALLIQ;
        private System.Windows.Forms.Label LBLDESINSS;
        private System.Windows.Forms.Label LBLDESIRFF;
        private System.Windows.Forms.TextBox TXTAIRPF;
        private System.Windows.Forms.TextBox TXTSALF;
        private System.Windows.Forms.TextBox TXTSALL;
        private System.Windows.Forms.TextBox TXTDESIRPF;
        private System.Windows.Forms.ComboBox TXTNUMF;
        private System.Windows.Forms.Label LBLDADOS;
        private System.Windows.Forms.RadioButton RBNCAS;
        private System.Windows.Forms.GroupBox GPXSEXO;
        private System.Windows.Forms.RadioButton RBXM;
        private System.Windows.Forms.RadioButton RBXF;
        private System.Windows.Forms.MaskedTextBox MSKTXTSALB;
        private System.Windows.Forms.TextBox TXTNFUN;
        private System.Windows.Forms.TextBox TXTAINSS;
        private System.Windows.Forms.TextBox TXTDESINSS;
        private System.Windows.Forms.Label label1;
    }
}

