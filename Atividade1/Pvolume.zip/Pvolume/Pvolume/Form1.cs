﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e) //label do raio
        {

        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            double raio, altura;

            if(double.TryParse(TXTaltura.Text, out altura) &&
                double.TryParse(TxtRaio.Text, out raio))

            {
                if((altura <= 0) || (raio <= 0))
                {
                    MessageBox.Show("Altura e raio devem ser maior que zero!","Burro,tem que ser maior que zero!",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                    TxtRaio.Focus();
                }
                else
                {
                    double volume;
                    //volume - 3,14 * raio * raio * altura;
                    volume = Math.PI * Math.Pow(raio, 2) * altura;
                    TxtVolume.Text = volume.ToString("N2");
                }
            }
            else
            {
                MessageBox.Show("Valores Inválidos","Burro,erro o valor!",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                TxtRaio.Focus();
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            //Limpar os dados
            TXTaltura.Clear();
            TxtRaio.Text = "";
            TxtVolume.Text = string.Empty;

            TxtRaio.Focus();

        }

        private void TxtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==(char)13)
            {
                SendKeys.Send("{tab}");
                e.Handled = true;
            }
        } 

    }
}
