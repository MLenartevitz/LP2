﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label LblRaio;
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblVolume = new System.Windows.Forms.Label();
            this.BtnCalc = new System.Windows.Forms.Button();
            this.BtnLimp = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.TxtRaio = new System.Windows.Forms.TextBox();
            this.TXTaltura = new System.Windows.Forms.TextBox();
            this.TxtVolume = new System.Windows.Forms.TextBox();
            LblRaio = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LblRaio
            // 
            LblRaio.AutoSize = true;
            LblRaio.BackColor = System.Drawing.Color.Transparent;
            LblRaio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            LblRaio.ForeColor = System.Drawing.Color.Black;
            LblRaio.Location = new System.Drawing.Point(106, 92);
            LblRaio.Name = "LblRaio";
            LblRaio.Size = new System.Drawing.Size(48, 18);
            LblRaio.TabIndex = 0;
            LblRaio.Text = "Raio:";
            LblRaio.Click += new System.EventHandler(this.label1_Click);
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.BackColor = System.Drawing.Color.Transparent;
            this.LblAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.LblAltura.ForeColor = System.Drawing.Color.Black;
            this.LblAltura.Location = new System.Drawing.Point(106, 187);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(56, 18);
            this.LblAltura.TabIndex = 1;
            this.LblAltura.Text = "Altura:";
            // 
            // LblVolume
            // 
            this.LblVolume.AutoSize = true;
            this.LblVolume.BackColor = System.Drawing.Color.Transparent;
            this.LblVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.LblVolume.ForeColor = System.Drawing.Color.Black;
            this.LblVolume.Location = new System.Drawing.Point(106, 268);
            this.LblVolume.Name = "LblVolume";
            this.LblVolume.Size = new System.Drawing.Size(69, 18);
            this.LblVolume.TabIndex = 2;
            this.LblVolume.Text = "Volume:";
            // 
            // BtnCalc
            // 
            this.BtnCalc.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.OIP__2_;
            this.BtnCalc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnCalc.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnCalc.Location = new System.Drawing.Point(276, 506);
            this.BtnCalc.Name = "BtnCalc";
            this.BtnCalc.Size = new System.Drawing.Size(186, 110);
            this.BtnCalc.TabIndex = 3;
            this.BtnCalc.Text = "Calcular";
            this.BtnCalc.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnCalc.UseVisualStyleBackColor = true;
            this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // BtnLimp
            // 
            this.BtnLimp.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.OIP;
            this.BtnLimp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnLimp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnLimp.Location = new System.Drawing.Point(554, 506);
            this.BtnLimp.Name = "BtnLimp";
            this.BtnLimp.Size = new System.Drawing.Size(186, 110);
            this.BtnLimp.TabIndex = 4;
            this.BtnLimp.Text = "Limpar";
            this.BtnLimp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnLimp.UseVisualStyleBackColor = true;
            this.BtnLimp.Click += new System.EventHandler(this.BtnLimp_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.OIP__1_;
            this.BtnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnSair.Location = new System.Drawing.Point(824, 505);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(186, 110);
            this.BtnSair.TabIndex = 5;
            this.BtnSair.Text = "Sair";
            this.BtnSair.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // TxtRaio
            // 
            this.TxtRaio.Location = new System.Drawing.Point(184, 93);
            this.TxtRaio.Name = "TxtRaio";
            this.TxtRaio.Size = new System.Drawing.Size(254, 20);
            this.TxtRaio.TabIndex = 6;
            this.TxtRaio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtRaio_KeyPress);
            // 
            // TXTaltura
            // 
            this.TXTaltura.Location = new System.Drawing.Point(184, 185);
            this.TXTaltura.Name = "TXTaltura";
            this.TXTaltura.Size = new System.Drawing.Size(254, 20);
            this.TXTaltura.TabIndex = 7;
            this.TXTaltura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtRaio_KeyPress);
            // 
            // TxtVolume
            // 
            this.TxtVolume.Enabled = false;
            this.TxtVolume.Location = new System.Drawing.Point(184, 266);
            this.TxtVolume.Name = "TxtVolume";
            this.TxtVolume.Size = new System.Drawing.Size(254, 20);
            this.TxtVolume.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Now_Enrolling_1;
            this.ClientSize = new System.Drawing.Size(1433, 820);
            this.Controls.Add(this.TxtVolume);
            this.Controls.Add(this.TXTaltura);
            this.Controls.Add(this.TxtRaio);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimp);
            this.Controls.Add(this.BtnCalc);
            this.Controls.Add(this.LblVolume);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(LblRaio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblVolume;
        private System.Windows.Forms.Button BtnCalc;
        private System.Windows.Forms.Button BtnLimp;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.TextBox TxtRaio;
        private System.Windows.Forms.TextBox TXTaltura;
        private System.Windows.Forms.TextBox TxtVolume;

    }
}

