﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;



namespace Pcampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int N = 8;
            int TGF = 0;
            int TGR = 0;

            var aux2 = Interaction.InputBox("Quantidade de times: ", "Numero de times");
            int.TryParse(aux2, out N);

            int SalGol = 0;

            int[,] MGols = new int[N, 3];

            for (int i = 0; i < N; i++)
            {

                for (int j = 0; j < MGols.Length; j++)
                {

                    if (j == 0)
                    {
                        var aux = Interaction.InputBox("Gols Feitos: ", "Entrada de Gols Feitos");
                        TGF += Convert.ToInt32(aux);

                        if (!int.TryParse(aux, out MGols[i, 1]))
                        {
                            MessageBox.Show("Erro, quantidade de times maior que o permitido!");
                            j--;
                            continue;
                        }

                    }
                    else
                        if (j == 1)
                        {
                            var aux = Interaction.InputBox("Gols Recebidos: ", "Entrada de Gols Recebidos");
                            TGR += Convert.ToInt32(aux);

                            if (!int.TryParse(aux, out MGols[i, 2]))
                            {
                                MessageBox.Show("Erro!");
                                j--;
                                continue;
                            }
                        }
                }

                SalGol = MGols[i, 1] - MGols[i, 2];
                lstbSaida.Items.Add("Time: " + (i + 1) + " Gols Feitos: " + MGols[i, 1] + " Gols Recebidos: " + MGols[i, 2] + " Saldo de Gols: " + SalGol + "\n");
            }
            lstbSaida.Items.Add(" Total de gols feitos: " + TGF);
            lstbSaida.Items.Add(" Total de gols recebidos: " + TGR);
        }

    }
}
