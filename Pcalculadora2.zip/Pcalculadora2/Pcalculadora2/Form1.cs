namespace Pcalculadora2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) //BtnSub
        {
            double valor1, valor2;

            if (double.TryParse(Txtval1.Text, out valor1) &&
                double.TryParse(Txtval2.Text, out valor2))

            {

                double resultado;
                //resultado = valor1 - valor2;
                resultado = valor1 - valor2;
                Txtre.Text = resultado.ToString("N2");

            }
            else
            {
                MessageBox.Show("Valores Inv�lidos", "Erro o valor!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Txtval1.Focus();
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            //Limpar os dados
            Txtval1.Clear();
            Txtval2.Text = "";
            Txtre.Text = string.Empty;

            Txtval1.Focus();

        }

        private void Txtval1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{tab}");
                e.Handled = true;
            }

        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            double valor1, valor2;

            if (double.TryParse(Txtval1.Text, out valor1) &&
                double.TryParse(Txtval2.Text, out valor2))

            {

                double resultado;
                //resultado = valor1 + valor2;
                resultado = valor1 + valor2;
                Txtre.Text = resultado.ToString("N2");

            }
            else
            {
                MessageBox.Show("Valores Inv�lidos", "Erro o valor!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Txtval1.Focus();
            }
        }

        private void BtnMulti_Click(object sender, EventArgs e)
        {
            double valor1, valor2;

            if (double.TryParse(Txtval1.Text, out valor1) &&
                double.TryParse(Txtval2.Text, out valor2))

            {

                double resultado;
                //resultado = valor1 * valor2;
                resultado = valor1 * valor2;
                Txtre.Text = resultado.ToString("N2");

            }
            else
            {
                MessageBox.Show("Valores Inv�lidos", "Erro o valor!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Txtval1.Focus();
            }
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            double valor1, valor2;

            if (double.TryParse(Txtval1.Text, out valor1) &&
                double.TryParse(Txtval2.Text, out valor2))

            {

                if (valor2 <= 0)
                {
                    MessageBox.Show("O dividendo tem que ser maior que zero!", "Erro de valor!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Txtval2.Focus();
                }
                else
                {
                    double resultado;
                    //resultado = valor1 / valor2;
                    resultado = valor1 / valor2;
                    Txtre.Text = resultado.ToString("N2");
                }
            }
            else
            {
                MessageBox.Show("Valores Inv�lidos", "Erro o valor!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Txtval1.Focus();
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
    
}