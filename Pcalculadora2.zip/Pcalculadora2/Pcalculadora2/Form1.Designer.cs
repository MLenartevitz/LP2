﻿namespace Pcalculadora2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lblval1 = new System.Windows.Forms.Label();
            this.Lblval2 = new System.Windows.Forms.Label();
            this.Lblre = new System.Windows.Forms.Label();
            this.Txtval1 = new System.Windows.Forms.TextBox();
            this.Txtval2 = new System.Windows.Forms.TextBox();
            this.Txtre = new System.Windows.Forms.TextBox();
            this.BtnSoma = new System.Windows.Forms.Button();
            this.BtnSub = new System.Windows.Forms.Button();
            this.BtnMulti = new System.Windows.Forms.Button();
            this.BtnDiv = new System.Windows.Forms.Button();
            this.BtnLimp = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Lblval1
            // 
            this.Lblval1.AutoSize = true;
            this.Lblval1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lblval1.Location = new System.Drawing.Point(12, 42);
            this.Lblval1.Name = "Lblval1";
            this.Lblval1.Size = new System.Drawing.Size(55, 18);
            this.Lblval1.TabIndex = 0;
            this.Lblval1.Text = "Valor1:";
            this.Lblval1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Lblval2
            // 
            this.Lblval2.AutoSize = true;
            this.Lblval2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lblval2.Location = new System.Drawing.Point(12, 71);
            this.Lblval2.Name = "Lblval2";
            this.Lblval2.Size = new System.Drawing.Size(55, 18);
            this.Lblval2.TabIndex = 1;
            this.Lblval2.Text = "Valor2:";
            // 
            // Lblre
            // 
            this.Lblre.AutoSize = true;
            this.Lblre.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lblre.Location = new System.Drawing.Point(12, 96);
            this.Lblre.Name = "Lblre";
            this.Lblre.Size = new System.Drawing.Size(84, 18);
            this.Lblre.TabIndex = 2;
            this.Lblre.Text = "Resultado:";
            // 
            // Txtval1
            // 
            this.Txtval1.Location = new System.Drawing.Point(91, 37);
            this.Txtval1.Name = "Txtval1";
            this.Txtval1.Size = new System.Drawing.Size(141, 23);
            this.Txtval1.TabIndex = 3;
            this.Txtval1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtval1_KeyPress);
            // 
            // Txtval2
            // 
            this.Txtval2.Location = new System.Drawing.Point(91, 66);
            this.Txtval2.Name = "Txtval2";
            this.Txtval2.Size = new System.Drawing.Size(141, 23);
            this.Txtval2.TabIndex = 4;
            this.Txtval2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtval1_KeyPress);
            // 
            // Txtre
            // 
            this.Txtre.Enabled = false;
            this.Txtre.Location = new System.Drawing.Point(91, 95);
            this.Txtre.Name = "Txtre";
            this.Txtre.Size = new System.Drawing.Size(141, 23);
            this.Txtre.TabIndex = 5;
            // 
            // BtnSoma
            // 
            this.BtnSoma.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnSoma.Location = new System.Drawing.Point(21, 140);
            this.BtnSoma.Name = "BtnSoma";
            this.BtnSoma.Size = new System.Drawing.Size(75, 39);
            this.BtnSoma.TabIndex = 6;
            this.BtnSoma.Text = "+";
            this.BtnSoma.UseVisualStyleBackColor = true;
            this.BtnSoma.Click += new System.EventHandler(this.BtnSoma_Click);
            // 
            // BtnSub
            // 
            this.BtnSub.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnSub.Location = new System.Drawing.Point(134, 140);
            this.BtnSub.Name = "BtnSub";
            this.BtnSub.Size = new System.Drawing.Size(75, 39);
            this.BtnSub.TabIndex = 7;
            this.BtnSub.Text = "-";
            this.BtnSub.UseVisualStyleBackColor = true;
            this.BtnSub.Click += new System.EventHandler(this.button2_Click);
            // 
            // BtnMulti
            // 
            this.BtnMulti.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnMulti.Location = new System.Drawing.Point(21, 209);
            this.BtnMulti.Name = "BtnMulti";
            this.BtnMulti.Size = new System.Drawing.Size(75, 39);
            this.BtnMulti.TabIndex = 8;
            this.BtnMulti.Text = "*";
            this.BtnMulti.UseVisualStyleBackColor = true;
            this.BtnMulti.Click += new System.EventHandler(this.BtnMulti_Click);
            // 
            // BtnDiv
            // 
            this.BtnDiv.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnDiv.Location = new System.Drawing.Point(134, 209);
            this.BtnDiv.Name = "BtnDiv";
            this.BtnDiv.Size = new System.Drawing.Size(75, 39);
            this.BtnDiv.TabIndex = 9;
            this.BtnDiv.Text = "/";
            this.BtnDiv.UseVisualStyleBackColor = true;
            this.BtnDiv.Click += new System.EventHandler(this.BtnDiv_Click);
            // 
            // BtnLimp
            // 
            this.BtnLimp.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnLimp.Location = new System.Drawing.Point(77, 264);
            this.BtnLimp.Name = "BtnLimp";
            this.BtnLimp.Size = new System.Drawing.Size(75, 43);
            this.BtnLimp.TabIndex = 10;
            this.BtnLimp.Text = "Limpar";
            this.BtnLimp.UseVisualStyleBackColor = true;
            this.BtnLimp.Click += new System.EventHandler(this.BtnLimp_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnSair.Location = new System.Drawing.Point(77, 326);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 39);
            this.BtnSair.TabIndex = 11;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Ink Free", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(28, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "CALCULADORA  2000";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(240, 399);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimp);
            this.Controls.Add(this.BtnDiv);
            this.Controls.Add(this.BtnMulti);
            this.Controls.Add(this.BtnSub);
            this.Controls.Add(this.BtnSoma);
            this.Controls.Add(this.Txtre);
            this.Controls.Add(this.Txtval2);
            this.Controls.Add(this.Txtval1);
            this.Controls.Add(this.Lblre);
            this.Controls.Add(this.Lblval2);
            this.Controls.Add(this.Lblval1);
            this.Name = "Form1";
            this.Text = "calculadora 2000";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Lblval1;
        private Label Lblval2;
        private Label Lblre;
        private TextBox Txtval1;
        private TextBox Txtval2;
        private TextBox Txtre;
        private Button BtnSoma;
        private Button BtnSub;
        private Button BtnMulti;
        private Button BtnDiv;
        private Button BtnLimp;
        private Button BtnSair;
        private Label label1;
    }
}