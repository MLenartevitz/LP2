﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PexerciciosAula8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnQntdEspacos_Click(object sender, EventArgs e)
        {
            int QE = 0; 

            for (int i = 0; i < rchTxtFrase.Text.Length; i++)
            {
                if (rchTxtFrase.Text[i] == ' ') 
                {
                    QE += 1; 
                }
            }

            MessageBox.Show("A Quantidade de Espaços em Branco eh: " + QE);
        }

        private void btnQntdR_Click(object sender, EventArgs e)
        {
            int i, QR = 0; 

            i = 0;
            while (i < rchTxtFrase.Text.Length) 
            {
                if (rchTxtFrase.Text[i] == 'R' || rchTxtFrase.Text[i] == 'r') 
                {
                    QR += 1; 
                }

                i++; 
            }

            MessageBox.Show("A Quantidade de 'R' eh: " + QR);
        }

        private void btnQntdPares_Click(object sender, EventArgs e)
        {
            int QE = 0; 

            for (int i = 0; i < rchTxtFrase.Text.Length; i++) 
            {
                if (i > 0)
                {
                    if (rchTxtFrase.Text[i] == rchTxtFrase.Text[i - 1]) 
                    {
                        QE += 1; 
                        i++; 
                    }
                }
            }

            MessageBox.Show("A Quantidade de Pares eh: " + QE);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchTxtFrase.Text = ""; 
        }

        private void frmExercicio1_Load(object sender, EventArgs e)
        {
            //Oi linda <3
        }
    }
}
