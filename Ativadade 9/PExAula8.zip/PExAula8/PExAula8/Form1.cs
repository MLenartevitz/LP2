namespace PexerciciosAula8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio1"]; 
            if (fc != null)
                fc.Close();

            frmExercicio1 frm1 = new frmExercicio1(); 
            frm1.Show();
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio2"];
            if (fc != null)
                fc.Close();

            frmExercicio2 frm2 = new frmExercicio2();
            frm2.Show();
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio3"];
            if (fc != null)
                fc.Close();

            frmExercicio3 frm3 = new frmExercicio3();
            frm3.Show();
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio4"];
            if (fc != null)
                fc.Close();

            frmExercicio4 frm4 = new frmExercicio4();
            frm4.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            // oi, sem querer cliquei duas vezes
        }
    }
}