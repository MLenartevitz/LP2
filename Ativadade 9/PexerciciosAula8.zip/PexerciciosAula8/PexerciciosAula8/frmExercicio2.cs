﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PexerciciosAula8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double num; 
            double result = 1; 

            if (Double.TryParse(txtNum.Text, out num)) 
            {
                if (num <= 0) 
                {
                    MessageBox.Show("Não pode ser 0!");
                }
                else 
                {
                    for (int i = 2; i <= num; i++) 
                    {
                        result += 1.0 / i; 
                    }

                    txtResult.Text = result.ToString("N2"); 
                }
            }
            else 
            {
                MessageBox.Show("Valor Inválido!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum.Text = ""; 
            txtResult.Text = ""; 
        }

        private void lblNumero_Click(object sender, EventArgs e)
        {

        }
    }
}
