﻿namespace PexerciciosAula8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string aux1, aux2; 

            if (String.IsNullOrEmpty(txtFr.Text)) 
            {
                MessageBox.Show("Informe uma Frase primeiro!");         
            }
            else 
            {
                if (txtFr.Text.Length <= 50) 
                {
                    aux1 = txtFr.Text.ToUpper().Replace(" ", ""); 
                    aux2 = aux1;
                    char[] auxVetor = aux1.ToCharArray(); 

                    Array.Reverse(auxVetor); 

                    aux1 = ""; 

                    foreach (var element in auxVetor) 
                    {
                          aux1 += element; 
                    }

                    if (aux1 == aux2) 
                    {
                        txtResult.Text = "A palavra é um Palíndromo!";
                    }
                    else
                    {
                        txtResult.Text = "A palavra não é um Palíndromo!";
                    }
                }
                else
                {
                    MessageBox.Show("Frase é muito grande!");
                }
            }
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            txtFr.Text = ""; 
            txtResult.Text = ""; 
        }
    }
}
