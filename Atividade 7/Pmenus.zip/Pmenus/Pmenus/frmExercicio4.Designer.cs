﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RTB = new System.Windows.Forms.RichTextBox();
            this.btnPCB = new System.Windows.Forms.Button();
            this.btncaralf = new System.Windows.Forms.Button();
            this.btncarnum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RTB
            // 
            this.RTB.Location = new System.Drawing.Point(264, 12);
            this.RTB.Name = "RTB";
            this.RTB.Size = new System.Drawing.Size(154, 141);
            this.RTB.TabIndex = 0;
            this.RTB.Text = "";
            // 
            // btnPCB
            // 
            this.btnPCB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPCB.Location = new System.Drawing.Point(161, 233);
            this.btnPCB.Name = "btnPCB";
            this.btnPCB.Size = new System.Drawing.Size(120, 58);
            this.btnPCB.TabIndex = 9;
            this.btnPCB.Text = "Primeiro Caracter Branco";
            this.btnPCB.UseVisualStyleBackColor = true;
            this.btnPCB.Click += new System.EventHandler(this.btnPCB_Click);
            // 
            // btncaralf
            // 
            this.btncaralf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncaralf.Location = new System.Drawing.Point(298, 233);
            this.btncaralf.Name = "btncaralf";
            this.btncaralf.Size = new System.Drawing.Size(120, 58);
            this.btncaralf.TabIndex = 8;
            this.btncaralf.Text = "Caracteres alfabeticos";
            this.btncaralf.UseVisualStyleBackColor = true;
            this.btncaralf.Click += new System.EventHandler(this.btncaralf_Click);
            // 
            // btncarnum
            // 
            this.btncarnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncarnum.Location = new System.Drawing.Point(20, 233);
            this.btncarnum.Name = "btncarnum";
            this.btncarnum.Size = new System.Drawing.Size(120, 58);
            this.btncarnum.TabIndex = 7;
            this.btncarnum.Text = "Caracteres numerico";
            this.btncarnum.UseVisualStyleBackColor = true;
            this.btncarnum.Click += new System.EventHandler(this.btncarnum_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Pmenus.Properties.Resources.homem_de_ferro_tony_divulgacao3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(430, 331);
            this.Controls.Add(this.btnPCB);
            this.Controls.Add(this.btncaralf);
            this.Controls.Add(this.btncarnum);
            this.Controls.Add(this.RTB);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RTB;
        private System.Windows.Forms.Button btnPCB;
        private System.Windows.Forms.Button btncaralf;
        private System.Windows.Forms.Button btncarnum;
    }
}