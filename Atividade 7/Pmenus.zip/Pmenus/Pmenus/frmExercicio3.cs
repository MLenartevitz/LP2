﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void frmExercicio3_Load(object sender, EventArgs e)
        {

        }

        private void btnrem1_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            Txtpal1.Text = Txtpal1.Text.ToUpper();
            Txtpal2.Text = Txtpal2.Text.ToUpper();

            posicao = Txtpal2.Text.IndexOf(Txtpal1.Text);

            while (posicao >= 0)
            {
                Txtpal2.Text = Txtpal2.Text.Substring(0, posicao) +
                Txtpal2.Text.Substring(posicao + Txtpal1.Text.Length,
                Txtpal2.Text.Length - posicao - Txtpal1.Text.Length);

                posicao = Txtpal2.Text.IndexOf(Txtpal1.Text);
            }

        }

        private void btnrem2_Click(object sender, EventArgs e)
        {
            Txtpal1.Text = Txtpal1.Text.ToUpper();
            Txtpal2.Text = Txtpal2.Text.ToUpper();

            Txtpal2.Text = Txtpal2.Text.Replace(Txtpal1.Text,"");
        }

        private void btninvert_Click(object sender, EventArgs e)
        {
            string auxiliar = Txtpal1.Text;
            char[] arr = auxiliar.ToArray();
            Array.Reverse(arr);

            auxiliar = "";

            foreach (char cara in arr)
            {
                auxiliar = auxiliar + cara.ToString();
            }


            MessageBox.Show(auxiliar);

       }
    }
}
