﻿namespace Pmenus
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnrem2 = new System.Windows.Forms.Button();
            this.btninvert = new System.Windows.Forms.Button();
            this.btnrem1 = new System.Windows.Forms.Button();
            this.Txtpal2 = new System.Windows.Forms.TextBox();
            this.Txtpal1 = new System.Windows.Forms.TextBox();
            this.lblpal2 = new System.Windows.Forms.Label();
            this.lblpal1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnrem2
            // 
            this.btnrem2.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrem2.Location = new System.Drawing.Point(157, 194);
            this.btnrem2.Name = "btnrem2";
            this.btnrem2.Size = new System.Drawing.Size(120, 58);
            this.btnrem2.TabIndex = 13;
            this.btnrem2.Text = "Remove ocorrência (replace)";
            this.btnrem2.UseVisualStyleBackColor = true;
            this.btnrem2.Click += new System.EventHandler(this.btnrem2_Click);
            // 
            // btninvert
            // 
            this.btninvert.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninvert.Location = new System.Drawing.Point(294, 194);
            this.btninvert.Name = "btninvert";
            this.btninvert.Size = new System.Drawing.Size(120, 58);
            this.btninvert.TabIndex = 12;
            this.btninvert.Text = "Inverte (Reverse)";
            this.btninvert.UseVisualStyleBackColor = true;
            this.btninvert.Click += new System.EventHandler(this.btninvert_Click);
            // 
            // btnrem1
            // 
            this.btnrem1.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrem1.Location = new System.Drawing.Point(16, 194);
            this.btnrem1.Name = "btnrem1";
            this.btnrem1.Size = new System.Drawing.Size(120, 58);
            this.btnrem1.TabIndex = 11;
            this.btnrem1.Text = "Remove ocorrência";
            this.btnrem1.UseVisualStyleBackColor = true;
            this.btnrem1.Click += new System.EventHandler(this.btnrem1_Click);
            // 
            // Txtpal2
            // 
            this.Txtpal2.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txtpal2.Location = new System.Drawing.Point(132, 121);
            this.Txtpal2.Name = "Txtpal2";
            this.Txtpal2.Size = new System.Drawing.Size(122, 23);
            this.Txtpal2.TabIndex = 10;
            // 
            // Txtpal1
            // 
            this.Txtpal1.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txtpal1.Location = new System.Drawing.Point(132, 78);
            this.Txtpal1.Name = "Txtpal1";
            this.Txtpal1.Size = new System.Drawing.Size(122, 23);
            this.Txtpal1.TabIndex = 9;
            // 
            // lblpal2
            // 
            this.lblpal2.AutoSize = true;
            this.lblpal2.BackColor = System.Drawing.Color.Transparent;
            this.lblpal2.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpal2.ForeColor = System.Drawing.Color.White;
            this.lblpal2.Location = new System.Drawing.Point(51, 124);
            this.lblpal2.Name = "lblpal2";
            this.lblpal2.Size = new System.Drawing.Size(75, 16);
            this.lblpal2.TabIndex = 8;
            this.lblpal2.Text = "Palavra 2";
            // 
            // lblpal1
            // 
            this.lblpal1.AutoSize = true;
            this.lblpal1.BackColor = System.Drawing.Color.Transparent;
            this.lblpal1.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpal1.ForeColor = System.Drawing.Color.White;
            this.lblpal1.Location = new System.Drawing.Point(51, 81);
            this.lblpal1.Name = "lblpal1";
            this.lblpal1.Size = new System.Drawing.Size(75, 16);
            this.lblpal1.TabIndex = 7;
            this.lblpal1.Text = "Palavra 1";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Pmenus.Properties.Resources.homem_de_ferro_tony_divulgacao2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(430, 331);
            this.Controls.Add(this.btnrem2);
            this.Controls.Add(this.btninvert);
            this.Controls.Add(this.btnrem1);
            this.Controls.Add(this.Txtpal2);
            this.Controls.Add(this.Txtpal1);
            this.Controls.Add(this.lblpal2);
            this.Controls.Add(this.lblpal1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.Load += new System.EventHandler(this.frmExercicio3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnrem2;
        private System.Windows.Forms.Button btninvert;
        private System.Windows.Forms.Button btnrem1;
        private System.Windows.Forms.TextBox Txtpal2;
        private System.Windows.Forms.TextBox Txtpal1;
        private System.Windows.Forms.Label lblpal2;
        private System.Windows.Forms.Label lblpal1;
    }
}