﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //BtnInv
        {
            int[] vector = new int[20];
            string aux;
            string saida = "";
            for(var i = 0;i < 20; i++ )
            {
                aux = Interaction.InputBox("Digite o número","Entrada de dados");
                    if(!Int32.TryParse(aux, out vector[i]))
                    {
                       MessageBox.Show("Dados inválidos");
                       i--;
                    }
                    else
                    {
                        saida = vector[i] + "\n" + saida;
                    }
                MessageBox.Show(saida);
            }                            
        }

        private void button2_Click(object sender, EventArgs e) //BtnMerc
        {
            double[] QTD = new double[10];
            double[] VLR = new double[10];
            string aux = "";
            double fat = 0;

            for(var i = 0; i < 10; i++)
            {
                aux = Interaction.InputBox("Digite a quantidade de mercadoria" + (i + 1), "entrada de quantidade");

                if(!double.TryParse(aux, out QTD[i]))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    while (VLR[i] <=0)
                    {
                        aux = "";
                        aux = Interaction.InputBox("Digite o valor da mercadoria" + (i + 1), "entrada de quantidade");

                        if(!double.TryParse(aux, out VLR[i]))
                        {
                            MessageBox.Show("Preço inválido");
                        }
                    }
                }
                fat += QTD[i] + VLR[i];
            }
            MessageBox.Show(fat.ToString("N2"));
        }

        private void button4_Click(object sender, EventArgs e) //BtnVar
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" }; 
            Int32 I, Total = 0; 
            Int32 N = Alunos.Length; 
            for (I = 0; I < N - 1; I++)
            { 
                Total += Alunos[I].Length;
                MessageBox.Show(Total.ToString("N2")); 
            }
        }

        private void BtnArray_Click(object sender, EventArgs e)
        {
            List<string> Nomes = new List<string>()
            {"Igor", "André", "Gabriel", "Fátima", "João", "Janete", "Pedro", "Marcelo", "Pedro", "Thais"};

            Nomes.Remove("Pedro");

            for (int i = 0; i < Nomes.Count; i++)
            {
                MessageBox.Show(Nomes[i]);
            }
        }

        private void BtnAl_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            double media = 0;
            string stringona;

            for (int i = 0; i < 20; i++)
                for (int j = 0; j < 3; j++)
                {
                    stringona = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1), "Entrada de Dados");

                    if (!double.TryParse(stringona, out Notas[i, j]))
                    {
                        MessageBox.Show("Nota Inválida \nDigite Novamente");
                        i--;
                    }
                    else
                    {
                        if (!(Notas[i, j] >= 0) && (Notas[i, j] <= 10))
                        {
                            MessageBox.Show("Nota Inválida \nDigite Novamente");
                            j--;
                        }
                        else
                        {
                            media = (Notas[i, 0] + Notas[i, 1] + Notas[i, 2]) / 3;
                            MessageBox.Show("Aluno " + (i + 1) + " Média: " + media.ToString("N2"));
                        }
                    }
                }
        }

        private void BtnPe_Click(object sender, EventArgs e)
        {
            double valid = 0;
            string RaEsc;
            int Ra;

            RaEsc = Interaction.InputBox("Digite o seu RA ", "Entrada de dados");

            if (double.TryParse(RaEsc, out valid))
            {
                RaEsc = RaEsc.Substring(RaEsc.Length - 1, 1);
            }
            else
            {
                MessageBox.Show("RA inválido!");
            }
            int.TryParse(RaEsc, out Ra);

            if (Ra == 0)
            {
                Ra = 10;
            }
            string[] nomes = new string[Ra];
            string[] aux = new string[Ra];
            int[] compr = new int[Ra];

            for (var i = 0; i < Ra; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome completo " + (i + 1), "Entrada de dados");
                if (double.TryParse(nomes[i], out valid))
                {
                    MessageBox.Show("Somente Letras!");
                    i--;
                }
                else
                {
                    aux[i] = nomes[i].Replace(" ", "");
                    compr[i] = aux[i].Length;
                    MessageBox.Show("O nome: " + nomes[i] + " tem " + compr[i] + " caracteres");
                }
            }
        }
    }
}
