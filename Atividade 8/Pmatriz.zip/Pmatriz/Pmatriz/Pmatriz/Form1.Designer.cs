﻿namespace Pmatriz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnInv = new System.Windows.Forms.Button();
            this.BtnMerc = new System.Windows.Forms.Button();
            this.BtnArray = new System.Windows.Forms.Button();
            this.BtnVar = new System.Windows.Forms.Button();
            this.BtnPe = new System.Windows.Forms.Button();
            this.BtnAl = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnInv
            // 
            this.BtnInv.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BtnInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInv.Location = new System.Drawing.Point(26, 12);
            this.BtnInv.Name = "BtnInv";
            this.BtnInv.Size = new System.Drawing.Size(126, 92);
            this.BtnInv.TabIndex = 0;
            this.BtnInv.Text = "Ler 20 Números e Inverter";
            this.BtnInv.UseVisualStyleBackColor = true;
            this.BtnInv.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnMerc
            // 
            this.BtnMerc.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BtnMerc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnMerc.Location = new System.Drawing.Point(168, 12);
            this.BtnMerc.Name = "BtnMerc";
            this.BtnMerc.Size = new System.Drawing.Size(126, 92);
            this.BtnMerc.TabIndex = 1;
            this.BtnMerc.Text = "Ler QTD e VLR Mercadoria";
            this.BtnMerc.UseVisualStyleBackColor = true;
            this.BtnMerc.Click += new System.EventHandler(this.button2_Click);
            // 
            // BtnArray
            // 
            this.BtnArray.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BtnArray.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnArray.Location = new System.Drawing.Point(168, 110);
            this.BtnArray.Name = "BtnArray";
            this.BtnArray.Size = new System.Drawing.Size(126, 92);
            this.BtnArray.TabIndex = 2;
            this.BtnArray.Text = "ArrayList";
            this.BtnArray.UseVisualStyleBackColor = true;
            this.BtnArray.Click += new System.EventHandler(this.BtnArray_Click);
            // 
            // BtnVar
            // 
            this.BtnVar.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BtnVar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnVar.Location = new System.Drawing.Point(26, 110);
            this.BtnVar.Name = "BtnVar";
            this.BtnVar.Size = new System.Drawing.Size(126, 92);
            this.BtnVar.TabIndex = 3;
            this.BtnVar.Text = "Variável Total";
            this.BtnVar.UseVisualStyleBackColor = true;
            this.BtnVar.Click += new System.EventHandler(this.button4_Click);
            // 
            // BtnPe
            // 
            this.BtnPe.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BtnPe.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnPe.Location = new System.Drawing.Point(168, 208);
            this.BtnPe.Name = "BtnPe";
            this.BtnPe.Size = new System.Drawing.Size(126, 92);
            this.BtnPe.TabIndex = 4;
            this.BtnPe.Text = "Nomes Pessoas";
            this.BtnPe.UseVisualStyleBackColor = true;
            this.BtnPe.Click += new System.EventHandler(this.BtnPe_Click);
            // 
            // BtnAl
            // 
            this.BtnAl.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.BtnAl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.BtnAl.Location = new System.Drawing.Point(26, 208);
            this.BtnAl.Name = "BtnAl";
            this.BtnAl.Size = new System.Drawing.Size(126, 92);
            this.BtnAl.TabIndex = 5;
            this.BtnAl.Text = "Média Alunos";
            this.BtnAl.UseVisualStyleBackColor = true;
            this.BtnAl.Click += new System.EventHandler(this.BtnAl_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Pmatriz.Properties.Resources.download_linux;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(510, 383);
            this.Controls.Add(this.BtnAl);
            this.Controls.Add(this.BtnPe);
            this.Controls.Add(this.BtnVar);
            this.Controls.Add(this.BtnArray);
            this.Controls.Add(this.BtnMerc);
            this.Controls.Add(this.BtnInv);
            this.Cursor = System.Windows.Forms.Cursors.UpArrow;
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnInv;
        private System.Windows.Forms.Button BtnMerc;
        private System.Windows.Forms.Button BtnArray;
        private System.Windows.Forms.Button BtnVar;
        private System.Windows.Forms.Button BtnPe;
        private System.Windows.Forms.Button BtnAl;
    }
}

